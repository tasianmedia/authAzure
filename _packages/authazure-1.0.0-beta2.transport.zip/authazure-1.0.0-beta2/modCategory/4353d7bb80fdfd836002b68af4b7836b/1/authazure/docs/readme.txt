--------------------
Extra: authAzure
--------------------
Version: 1.0.0-beta2
Released: August 21, 2019
Since: August 22, 2018
Author: David Pede  <dev@tasian.media> <https://twitter.com/davepede>
Copyright: (C) 2019 David Pede. All rights reserved.

An Azure Active Directory Extra for MODX Revolution.

GitHub Repository:
https://github.com/tasianmedia/authazure

Bugs & Feature Requests:
https://github.com/tasianmedia/authazure/issues

License:
Released under the GNU General Public License; either version 2 of the License, or (at your option) any later version. http://www.gnu.org/licenses/gpl.html
