<?php
echo "<pre>";
print_r($_REQUEST);
echo "</pre>";
echo "<pre>";
print_r($_GET);
echo "</pre>";
echo "<pre>";
print_r($_POST);
echo "</pre>";
echo "<pre>";
print_r($_SESSION);
echo "</pre>";

//if (!$modx->user->hasSessionContext($ctxs)) {
// If we don't have an authorization code then get one

//Init Service
$authazure = $modx->getService('authazure', 'AuthAzure', $modx->getOption('authazure.core_path', null, $modx->getOption('core_path') . 'components/authazure/') . 'model/authazure/');
if (!($authazure instanceof AuthAzure)) return '';
//Init Provide
require_once $authazure->config['vendorPath'] . 'autoload.php';

$provider = new TheNetworg\OAuth2\Client\Provider\Azure([
    'clientId' => $modx->getOption('authazure.client_id'),
    'clientSecret' => $modx->getOption('authazure.client_secret'),
    'redirectUri' => 'https://prp.test/knet/loginopenid.html',
    'metadata' => $modx->getOption('authazure.openid_config_url'),
    'responseType' => 'id_token code',
    'responseMode' => 'form_post',
]);

if (!isset($_REQUEST['code'])) {
    try {
        //$authorizationUrl = $provider->getAuthorizationUrl();
        $authorizationUrl = $provider->getAuthorizationUrl([
            'scope' => [ //TODO move to sys setting
                'openid', 'email', 'profile', 'offline_access',
                'https://graph.microsoft.com/User.Read',
                'https://graph.microsoft.com/Directory.Read.All'
            ],
            'nonce' => '7362CAEA-9CA5-4B43-9BA3-34D7C303EBA7'//write a cache file and check it exists on return
        ]);
    } catch (\League\OAuth2\Client\Provider\Exception\IdentityProviderException $e) {
        // Failed to get user details
        echo $e->getTraceAsString();
        exit('Oh dear...');
    }

    // Get the state generated for you and store it to the session.
    $_SESSION['oauth2state'] = $provider->getState();

    // Redirect the user to the authorization URL.
    header('Location: ' . $authorizationUrl);
    echo "<pre>";
    print_r($authorizationUrl);
    echo "</pre>";
    exit;
    // Check given state against previously stored one to mitigate CSRF attack
} elseif (empty($_REQUEST['state']) || (isset($_SESSION['oauth2state']) && $_REQUEST['state'] !== $_SESSION['oauth2state'])) {
    if (isset($_SESSION['oauth2state'])) {
        unset($_SESSION['oauth2state']);
    }
    exit('Invalid state');
} else {

    echo "PROVIDER:";
    echo "<pre>";
    print_r($provider);
    echo "</pre>";

    echo "ACCESS TOKEN:";
    // Try to get an access token using the authorization code grant.
    try {
    $token = $provider->getAccessToken('authorization_code', [
        'code' => $_REQUEST['code']
    ]);
    } catch (\League\OAuth2\Client\Provider\Exception\IdentityProviderException $e) {
        // Failed to get user details
        echo "<pre>";
        print_r($e);
        echo "</pre>";
        exit('Oh dear...');
    }

    echo "ACCESS TOKEN:";
    echo "<pre>";
    //print_r(serialize($token));
    print_r($token);
    echo "</pre>";
    echo "ACCESS TOKEN GET:";
    echo "<pre>";
    //print_r(serialize($token));
    print_r($token->getToken());
    echo "</pre>";


    try {


        //$date = new DateTime($olddate );
        //$new_date_format = $date->format('Y-m-d H:i:s');

        // We have an access token, which we may use in authenticated
        // requests against the service provider's API.
        //echo 'Access Token: ' . $token->getToken() . "<br>";
        //echo 'Refresh Token: ' . $token->getRefreshToken() . "<br>";
        echo "Expired in: " . date('l dS \o\f F Y H:i:s', $token->getExpires()) . "<br>";
        echo 'Already expired? ' . ($token->hasExpired() ? 'expired' : 'not expired') . "<br>";

        // Using the access token, we may look up details about the
        // resource owner.
        $resourceOwner = $provider->getResourceOwner($token);

        echo "OpenID USERINFO:";
        $id_token = $resourceOwner->toArray();
        echo "<pre>";
        print_r($id_token); //this info is also encoded in $_REQUEST[id_token] https://jwt.ms/
        echo "</pre>";

        // Optional: Now you have a token you can look up a users profile data
        try {
            //echo $token->getToken();
            $body = [
                "ids" => $id_token['groups']
            ];
            $options['body'] = json_encode($body);
            $options['headers']['Content-Type'] = 'application/json;charset=UTF-8';

            echo "<pre>";
            print_r($options);
            echo "</pre>";

            $request = $provider->getAuthenticatedRequest(
                'get',
                //'https://graph.windows.net/PRPArchitectsLLP.onmicrosoft.com/me?api-version=1.6',
                //'https://graph.microsoft.com/beta/me/photo/$value',
                //'https://graph.microsoft.com/beta/me',
                //'https://graph.microsoft.com/v1.0/me',
                //'https://graph.microsoft.com/v1.0/users',
                //'https://graph.microsoft.com/v1.0/me/getMemberObjects',
                //'https://graph.microsoft.com/v1.0/directoryObjects/getByIds',
                //'https://graph.microsoft.com/v1.0/me/getMemberGroups',
                'https://graph.microsoft.com/v1.0/me/memberOf',
                $token

            );
            $response = $provider->getResponse($request);
            $body = $response->getBody();
            echo "API RESPONSE:";
            echo "<pre>";
            //$file = 'img/web/profile-photos/image.jpg';
            //$success = file_put_contents($file, $body);
            //print $success ? $file : 'Unable to save the file.';
            print_r(json_decode($body, true));
            echo "</pre>";
        } catch (Exception $e) {
            // Failed to get user details
            echo $e->getMessage();
            exit('Oh dear...');
        }

        // The provider provides a way to get an authenticated API request for
        // the service, using the access token; it returns an object conforming
        // to Psr\Http\Message\RequestInterface.
        /*$request = $provider->getAuthenticatedRequest(
                'GET',
                'https://graph.microsoft.com/v1.0/me',
                $token
            );
        //$response = GuzzleHttp\Psr7\str($request);
        $response = $provider->getResponse($request);
        echo $response;
        $body = $response->getBody();
        echo "API PROFILE BODY:";
        echo "<pre>";
        print_r( (array) json_decode($body, true));
        echo "</pre>";*/
    } catch (Exception $e) {
        // Failed to get the access token or user details.
        echo "<pre>";
        echo $e->getMessage();
        echo "</pre>";
        exit($e->getMessage());
    }
}

//CUSTOM NON-API VERSION
//Check for id token or errors
/*if (!$_REQUEST['id_token'] && !$_REQUEST['error']) {
	//Request azure id token
	$params = array (
		'client_id' => '9be8115f-3ee6-4b2e-a2a4-8cd4372e479f'
		,'response_type' => 'id_token'
		,'response_mode' => 'form_post'
		,'scope' => 'openid profile'
		,'nonce' => '7362CAEA-9CA5-4B43-9BA3-34D7C303EBA7'
		,'prompt' => 'login'
	);
	$endpoint = 'https://login.microsoftonline.com/PRPArchitectsLLP.onmicrosoft.com/oauth2/authorize';
	$url = $endpoint . "?" . http_build_query($params);

	$modx->sendRedirect($url);

	//$user = $modx->getObject('modUser', array('username' => 'dp.gmail'));
	//$user->addSessionContext('web');
} elseif ($_REQUEST['error']) {
	//Handle azure error
	print_r($_REQUEST);
} elseif ($_REQUEST['id_token']) {
	//Handle azure id token

	//function base64url_decode($data) {
	//  return base64_decode(str_pad(strtr($data, '-_', '+/'), strlen($data) + (4 - strlen($data) % 4) % 4, '=', STR_PAD_RIGHT));
	//}

	$token_pieces = explode('.', $_REQUEST['id_token']);
	echo "<pre>";
	print_r($_REQUEST['id_token']);
	echo "</pre>";
	echo "<pre>";
	print_r($token_pieces);
	echo "</pre>";
}*/
//}