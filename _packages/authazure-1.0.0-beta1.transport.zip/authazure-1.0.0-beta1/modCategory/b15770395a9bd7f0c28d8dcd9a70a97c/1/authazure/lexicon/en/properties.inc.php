<?php
/**
 * Element properties English Lexicon Entries for authAzure
 *
 * @package authAzure
 * @subpackage lexicon
 */

// Snippet lexicons
$_lang['authazure.login.loginTpl_desc'] = 'Name of a chunk serving as a template';
$_lang['authazure.login.logoutTpl_desc'] = 'Name of a chunk serving as a template';
