<?php
/**
 * @package authazure
 */
class AazProfile extends xPDOSimpleObject {}
?>